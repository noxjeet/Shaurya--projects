'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';
import { collegeList } from '@/lib/collegeList'; // make sure this file exists

export default function SignupPage() {
  const [name, setName] = useState('');
  const [college, setCollege] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const router = useRouter();

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();

    const res = await fetch('/api/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, college, email, password }),
    });

    if (res.ok) {
      alert('Registered successfully! Please log in.');
      router.push('/login');
    } else {
      alert('Signup failed');
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-black via-zinc-900 to-red-900 px-4">
      <form
        onSubmit={handleSignup}
        className="bg-zinc-900/80 backdrop-blur-lg border border-zinc-800 rounded-2xl shadow-2xl p-8 w-full max-w-md flex flex-col gap-5"
      >
        <h2 className="text-3xl font-extrabold mb-2 text-center text-white tracking-tight drop-shadow-lg">
          Sign Up
        </h2>

        <input
          type="text"
          placeholder="Full Name"
          className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
        />

        <select
          className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          value={college}
          onChange={(e) => setCollege(e.target.value)}
          required
        >
          <option value="">Select College</option>
          {collegeList.map((col) => (
            <option key={col} value={col}>
              {col}
            </option>
          ))}
        </select>

        <input
          type="email"
          placeholder="Email"
          className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />

        <input
          type="password"
          placeholder="Password"
          className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
        />

        <button
          type="submit"
          className="mt-4 w-full bg-red-700 hover:bg-red-800 text-white py-2 rounded font-bold tracking-wide transition-colors duration-200 shadow-lg"
        >
          Sign Up
        </button>
      </form>
    </div>
  );
}

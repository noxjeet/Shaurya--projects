// hooks/useAuth.ts

export const useAuth = () => {
  if (typeof window === 'undefined') return { isLoggedIn: false, role: null };

  const user = JSON.parse(localStorage.getItem("user") || "null");
  return {
    isLoggedIn: !!user,
    role: user?.role || null, // role can be 'admin' or 'participant'
  };
};

'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ParticipantDashboard() {
  const router = useRouter();
  const [userData, setUserData] = useState<{
    name: string;
    email: string;
    college: string;
    hall: string;
  } | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');

    if (!token || role !== 'participant') {
      router.push('/login');
      return;
    }

    // Simulate fetching user data
    const name = localStorage.getItem('name') || 'Participant';
    const email = localStorage.getItem('email') || 'you@example.com';
    const college = localStorage.getItem('college') || 'Unknown College';
    const hall = localStorage.getItem('hall') || ''; // "" means not allocated

    setUserData({ name, email, college, hall });
  }, []);

  if (!userData) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-black via-zinc-900 to-red-900">
        <div className="text-zinc-200 text-lg">Loading dashboard...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-red-900 py-10 px-2">
      <div className="max-w-xl mx-auto">
        <h1 className="text-4xl font-extrabold mb-8 text-white tracking-tight drop-shadow-lg">
          Welcome, {userData.name} <span className="animate-waving-hand">👋</span>
        </h1>
        <div className="bg-zinc-900/80 backdrop-blur-lg rounded-xl shadow-2xl p-8 flex flex-col gap-4 border border-zinc-800">
          <div>
            <span className="text-zinc-400 text-sm">Email</span>
            <div className="text-lg text-white font-semibold">{userData.email}</div>
          </div>
          <div>
            <span className="text-zinc-400 text-sm">College</span>
            <div className="text-lg text-white font-semibold">{userData.college}</div>
          </div>
          <div>
            <span className="text-zinc-400 text-sm">Hall Allocation Status</span>
            <div>
              {userData.hall ? (
                <span className="inline-block bg-red-700/80 text-white px-3 py-1 rounded-full font-bold text-base shadow">
                  {userData.hall}
                </span>
              ) : (
                <span className="inline-block bg-zinc-700/60 text-zinc-300 px-3 py-1 rounded-full font-semibold text-base shadow">
                  Not Allocated
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

'use client';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [passwordVisible, setPasswordVisible] = useState(false); // <-- NEW
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();

    const res = await fetch('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });

    if (res.ok) {
      const { token, role } = await res.json();
      localStorage.setItem('token', token);
      localStorage.setItem('role', role);
      window.dispatchEvent(new Event('authChange'));
      router.push(role === 'admin' ? '/admin/dashboard' : '/participant/dashboard');
    } else {
      alert('Invalid credentials');
    }
  };

  const togglePasswordVisibility = () => setPasswordVisible((v) => !v);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-black via-zinc-900 to-red-900 px-4">
      <form
        onSubmit={handleLogin}
        className="bg-zinc-900/80 backdrop-blur-lg border border-zinc-800 rounded-2xl shadow-2xl p-8 w-full max-w-md flex flex-col gap-6"
      >
        <h2 className="text-3xl font-extrabold mb-2 text-center text-white tracking-tight drop-shadow-lg">
          Login
        </h2>
        <input
          type="email"
          placeholder="Email"
          className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-4 py-2 focus:outline-none focus:ring-2 focus:ring-red-500"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
        />
        <div className="relative w-full">
          <input
            type={passwordVisible ? 'text' : 'password'}
            placeholder="Password"
            className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-red-500"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button
            type="button"
            onClick={togglePasswordVisibility}
            className="absolute right-2 top-1/2 transform -translate-y-1/2 text-zinc-400 hover:text-red-500 focus:outline-none"
            tabIndex={-1}
            aria-label={passwordVisible ? 'Hide password' : 'Show password'}
          >
            {passwordVisible ? (
              // Eye-off SVG
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path d="M13.875 18.825A10.05 10.05 0 0112 19c-5 0-9.27-3.11-11-7 1.39-2.65 3.76-4.84 6.73-6.08M1 1l22 22" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            ) : (
              // Eye SVG
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="12" r="3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            )}
          </button>
        </div>
        <button
          type="submit"
          className="mt-4 w-full bg-red-700 hover:bg-red-800 text-white py-2 rounded font-bold tracking-wide transition-colors duration-200 shadow-lg"
        >
          Login
        </button>
      </form>
    </div>
  );
}

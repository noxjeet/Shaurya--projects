'use client';
import React, { useEffect, useRef, useState } from 'react';
import { halls } from '../lib/data';

const SLIDE_DURATION = 2500; // 3 seconds

export default function Home() {
  const [active, setActive] = useState(0);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-advance logic
  useEffect(() => {
    // Clear any previous interval
    if (intervalRef.current) clearInterval(intervalRef.current);

    intervalRef.current = setInterval(() => {
      setActive(prev => (prev + 1) % halls.length);
    }, SLIDE_DURATION);

    // Cleanup on unmount
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [active]);

  // When user clicks, set active and reset timer
  const handleHallClick = (idx: number) => {
    setActive(idx);
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => {
      setActive(prev => (prev + 1) % halls.length);
    }, SLIDE_DURATION);
  };

  return (
    <main className="flex flex-col items-center min-h-screen bg-gradient-to-br from-black via-zinc-900 to-red-900 pt-32 px-6">
      <h2 className="text-4xl font-extrabold mb-6 text-white tracking-tight drop-shadow-lg">
        Welcome to Shaurya Hall Allocation
      </h2>
      <p className="text-lg mb-10 text-zinc-200 text-center">
        Browse the halls available for allocation:
      </p>

      {/* Hall Row */}
      <div className="flex justify-center items-end gap-8 mb-12 w-full max-w-4xl">
        {halls.map((hall, idx) => (
          <div
            key={hall.id}
            onClick={() => handleHallClick(idx)}
            className={`cursor-pointer transition-all duration-500 flex flex-col items-center
              ${idx === active
                ? 'scale-110 shadow-2xl border-2 border-red-600 bg-zinc-900/90 z-10'
                : 'scale-90 opacity-40 bg-zinc-900/60 hover:opacity-70'}
              rounded-2xl p-6`}
            style={{
              minWidth: 180,
              minHeight: 220,
              boxShadow: idx === active
                ? '0 8px 32px 0 rgba(220,38,38,0.4)'
                : '0 2px 8px 0 rgba(0,0,0,0.2)',
              borderColor: idx === active ? '#dc2626' : 'transparent',
            }}
          >
            <h3 className={`text-2xl font-bold mb-2 ${idx === active ? 'text-red-400' : 'text-zinc-400'}`}>
              {hall.name}
            </h3>
            <div className="w-16 h-16 bg-zinc-700 rounded-full mb-2 flex items-center justify-center text-zinc-300 text-xl">
              🏢
            </div>
            <p className="text-sm text-zinc-400">Capacity: {hall.capacity}</p>
          </div>
        ))}
      </div>

      {/* Hall Details */}
      <div className="max-w-2xl w-full bg-zinc-900/80 backdrop-blur-lg rounded-xl shadow-2xl p-8 border border-zinc-800 flex flex-col items-center">
        <div className="w-full h-48 bg-zinc-800 rounded-lg mb-4 flex items-center justify-center text-5xl text-zinc-500">
          🏢
        </div>
        <h3 className="text-2xl font-bold mb-2 text-red-400">{halls[active].name}</h3>
        <p className="text-zinc-200 mb-2 text-center">{halls[active].description}</p>
        <p className="text-sm text-zinc-400">
          <span className="font-semibold text-red-300">Capacity:</span> {halls[active].capacity}
        </p>
      </div>
    </main>
  );
}

'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { participants, halls } from '@/lib/data';

type SortKey = 'name' | 'college';
type SortOrder = 'asc' | 'desc';

export default function AdminDashboard() {
  const router = useRouter();
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [sortOrder, setSortOrder] = useState<SortOrder>('asc');
  const [searchName, setSearchName] = useState('');
  const [filterCollege, setFilterCollege] = useState('');
  const [searchHall, setSearchHall] = useState('');
  const [data, setData] = useState(participants);

  const colleges = Array.from(new Set(participants.map((p) => p.college))).sort();

  useEffect(() => {
    const token = localStorage.getItem('token');
    const role = localStorage.getItem('role');
    if (!token || role !== 'admin') {
      router.push('/login');
    }
  }, []);

  useEffect(() => {
    let filtered = participants.filter((p) =>
      p.name.toLowerCase().includes(searchName.toLowerCase()) &&
      (filterCollege ? p.college === filterCollege : true) &&
      p.hall.toLowerCase().includes(searchHall.toLowerCase())
    );

    filtered = filtered.sort((a, b) => {
      const valA = a[sortKey].toLowerCase();
      const valB = b[sortKey].toLowerCase();
      if (valA < valB) return sortOrder === 'asc' ? -1 : 1;
      if (valA > valB) return sortOrder === 'asc' ? 1 : -1;
      return 0;
    });

    setData(filtered);
  }, [sortKey, sortOrder, searchName, filterCollege, searchHall]);

  const arrow = (key: SortKey) => {
    if (sortKey !== key) return '⇅';
    return sortOrder === 'asc' ? '▲' : '▼';
  };

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortOrder('asc');
    }
  };

  const handleAssignHall = (participantId: number, hallName: string) => {
    setData((prev) =>
      prev.map((p) =>
        p.id === participantId ? { ...p, hall: hallName } : p
      )
    );
    // TODO: Call your backend API to persist this change!
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-zinc-900 to-red-900 py-10 px-2">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-4xl font-extrabold mb-8 text-white tracking-tight drop-shadow-lg">
          Admin Dashboard
        </h1>
        <div className="overflow-x-auto rounded-lg shadow-2xl bg-zinc-900/80 backdrop-blur-lg">
          <div className="max-h-[500px] overflow-y-auto">
            <table className="min-w-full">
              <thead className="sticky top-0 z-10 bg-zinc-900/90">
                {/* Search/Filter Row */}
                <tr>
                  <th className="px-4 py-3">
                    <input
                      type="text"
                      className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="Search Name"
                      value={searchName}
                      onChange={(e) => setSearchName(e.target.value)}
                    />
                  </th>
                  <th className="px-4 py-3">
                    <select
                      className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-red-500"
                      value={filterCollege}
                      onChange={(e) => setFilterCollege(e.target.value)}
                    >
                      <option value="">All Colleges</option>
                      {colleges.map((college) => (
                        <option key={college} value={college}>
                          {college}
                        </option>
                      ))}
                    </select>
                  </th>
                  <th className="px-4 py-3"></th>
                  <th className="px-4 py-3">
                    <input
                      type="text"
                      className="w-full border border-zinc-700 bg-zinc-900 text-white rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-red-500"
                      placeholder="Search Hall"
                      value={searchHall}
                      onChange={(e) => setSearchHall(e.target.value)}
                    />
                  </th>
                  <th className="px-4 py-3"></th>
                </tr>
                {/* Column Headers */}
                <tr>
                  <th
                    className="px-4 py-3 cursor-pointer select-none text-red-400 hover:text-red-300 transition"
                    onClick={() => toggleSort('name')}
                  >
                    Name <span>{arrow('name')}</span>
                  </th>
                  <th
                    className="px-4 py-3 cursor-pointer select-none text-red-400 hover:text-red-300 transition"
                    onClick={() => toggleSort('college')}
                  >
                    College <span>{arrow('college')}</span>
                  </th>
                  <th className="px-4 py-3 text-red-400">Email</th>
                  <th className="px-4 py-3 text-red-400">Hall</th>
                  <th className="px-4 py-3 text-red-400">Assign Hall</th>
                </tr>
              </thead>
              <tbody>
                {data.map((p, idx) => (
                  <tr
                    key={idx}
                    className={`border-t border-zinc-800 hover:bg-gradient-to-r hover:from-red-900/40 hover:to-zinc-900/60 transition`}
                  >
                    <td className="px-4 py-3 text-white font-medium">{p.name}</td>
                    <td className="px-4 py-3 text-zinc-200">{p.college}</td>
                    <td className="px-4 py-3 text-zinc-300">{p.email}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded text-xs font-semibold
                        ${p.hall ? 'bg-red-700/80 text-white' : 'bg-zinc-700/60 text-zinc-300'}`}>
                        {p.hall || 'Not Allocated'}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <select
                        className="border border-zinc-700 bg-zinc-900 text-white rounded px-2 py-1 focus:outline-none focus:ring-2 focus:ring-red-500"
                        value={p.hall}
                        onChange={(e) => handleAssignHall(p.id, e.target.value)}
                      >
                        <option value="">Not Allocated</option>
                        {halls.map((hall) => (
                          <option key={hall.id} value={hall.name}>
                            {hall.name}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ))}
                {data.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-6 text-zinc-400">
                      No participants found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

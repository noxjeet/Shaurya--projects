// app/api/login/route.ts
import { NextResponse } from 'next/server';

const dummyUsers = [
  { email: 'admin@shaurya.com', password: 'admin123', role: 'admin' },
  { email: 'user@shaurya.com', password: 'user123', role: 'participant' },
];

export async function POST(req: Request) {
  const { email, password } = await req.json();

  const user = dummyUsers.find(
    (u) => u.email === email && u.password === password
  );

  if (user) {
    return NextResponse.json({ token: 'fake-jwt-token', role: user.role });
  } else {
    return NextResponse.json({ error: 'Invalid credentials' }, { status: 401 });
  }
}

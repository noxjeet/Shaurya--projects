'use client';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';

const Navbar = () => {
  const router = useRouter();
  const [hydrated, setHydrated] = useState(false);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [role, setRole] = useState('');

  useEffect(() => {
    const checkAuth = () => {
      const token = localStorage.getItem('token');
      const storedRole = localStorage.getItem('role');
      setIsLoggedIn(!!token);
      setRole(storedRole || '');
    };
    checkAuth();
    window.addEventListener('authChange', checkAuth);
    setHydrated(true);
    return () => window.removeEventListener('authChange', checkAuth);
  }, []);

  const handleHallAllocationClick = () => {
    if (!isLoggedIn) {
      router.push('/login');
    } else if (role === 'admin') {
      router.push('/admin/dashboard');
    } else {
      router.push('/participant/dashboard');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    window.dispatchEvent(new Event('authChange'));
    setIsLoggedIn(false);
    router.push('/');
  };

  if (!hydrated) return null;

  return (
    <nav className="w-full flex justify-between items-center px-8 py-4 bg-black text-white fixed top-0 z-50">
      <div className="flex gap-6 items-center">
        <Link href="/">
          <img
            src="/Shauyua-logo-insta.png"
            alt="home"
            className="h-8 w-8 cursor-pointer hover:scale-110 transition-transform duration-200"
          />
        </Link>
        <button
          onClick={handleHallAllocationClick}
          className="px-4 py-2 rounded hover:bg-red-700 hover:text-white hover:shadow-lg transition-colors transition-shadow duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
        >
          Hall Allocation
        </button>
      </div>
      <div className="flex gap-4 items-center">
        {!isLoggedIn ? (
          <>
            <Link
              href="/login"
              className="px-4 py-2 rounded hover:bg-red-700 hover:text-white hover:shadow-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              Login
            </Link>
            <Link
              href="/signup"
              className="px-4 py-2 rounded hover:bg-red-700 hover:text-white hover:shadow-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              Signup
            </Link>
          </>
        ) : (
          <>
            <Link
              href={role === 'admin' ? "/admin/dashboard" : "/participant/dashboard"}
              className="px-4 py-2 rounded hover:bg-red-700 hover:text-white hover:shadow-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              Dashboard
            </Link>
            <button
              onClick={handleLogout}
              className="px-4 py-2 rounded hover:bg-red-700 hover:text-white hover:shadow-lg transition duration-200 focus:outline-none focus:ring-2 focus:ring-red-500"
            >
              Logout
            </button>
          </>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
